package com.auto.bdd.util;

public interface Constants {
	String HOME_PAGE = "HomePage";
	String RESPONSE_RULE_PAGE = "ResponseRulePage";
	String NEW_TEMPLATE_PAGE = "NewTemplatePage";
	public static final String WHISPER_URL = "http://au.whispir.com";
	
	


}
