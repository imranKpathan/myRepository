package com.auto.bdd.cucumber;

import java.net.MalformedURLException;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks{
    public static WebDriver driver;
//    public static String browser = System.getenv("Browser");
    public static String browser = "chrome";
 /*   
    @Before
    *//**
     * Delete all cookies at the start of each scenario to avoid
     * shared state between tests
     *//*
    public void openBrowser() throws MalformedURLException {
    	System.out.println("Called openBrowser");
    	if (browser.equalsIgnoreCase("iexplore")) {
    		String workingDir = System.getProperty("user.dir");
			System.setProperty("webdriver.ie.driver", workingDir+"\\config\\IEDriverServer.exe");
			DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
			  cap.setBrowserName("iexplore");
			//  cap.setJavascriptEnabled(true);
			  cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			  cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			  cap.setPlatform(org.openqa.selenium.Platform.ANY);
			  cap.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP, true);
			  driver = new InternetExplorerDriver(cap);
			  driver.manage().window().maximize();
			  driver.manage().deleteAllCookies();
		} else if (browser.equalsIgnoreCase("firefox")) {

			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			  driver.manage().deleteAllCookies();

		} else if (browser.equalsIgnoreCase("chrome")) {
			String workingDir = System.getProperty("user.dir");
			System.out.println("+++++++++"+System.getProperty("user.dir"));
			System.setProperty("webdriver.chrome.driver", workingDir+"\\config\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			  driver.manage().deleteAllCookies();
		} else if (browser.equalsIgnoreCase("safari")) {
			driver = new SafariDriver();
			driver.manage().window().maximize();
			  driver.manage().deleteAllCookies();
		}
    }

     
    @After
    *//**
     * Embed a screenshot in test report if test is marked as failed
     *//*
    public void embedScreenshot(Scenario scenario) {
       
        if(scenario.isFailed()) {
        try {
        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
//            byte[] screenshot = getScreenshotAs(OutputType.BYTES);
//        	 File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);  //-ORIGINAL
            
            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png");
            
            //-- ADDING BELOW FOR EXPERIEMENTING-----
            DateFormat dateFormat = new SimpleDateFormat("dd_MMM_yyyy__hh_mm_ssaa");
    		String destDir = "target/surefire-reports/screenshots";
            
    		new File(destDir).mkdirs();
    		String destFile = dateFormat.format(new Date()) + ".png";
    		
//    		FileUtils.copyFile(screenshot, new File(destDir + "/" + destFile));
            //-- ADDING ABOVE FOR EXPERIEMENTING-----
        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
            
            somePlatformsDontSupportScreenshots.printStackTrace();
        }
        
        }
        driver.quit();
        
    }
 */   
}