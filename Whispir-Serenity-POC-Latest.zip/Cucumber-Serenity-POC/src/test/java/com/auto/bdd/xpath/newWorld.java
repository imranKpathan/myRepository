package com.auto.bdd.xpath;

public class newWorld {

	public String Xpath(String field_name, String locator, String tagname){
		String xpath = null;
		/*
		switch(field_name){
		case("fieldset"): String xpath_fieldset = ".//fieldset[(./@id = %locator% or .//legend[contains(normalize-space(string(.)), %locator%)])]";
							xpath = xpath_fieldset.replace("%locator%", "'"+locator+"'") ;
							
							break;
		case("field"): String xpath_field =".//*[self::input | self::textarea | self::select][not(./@type = 'submit' or ./@type = 'image' or ./@type = 'hidden')][(((./@id = %locator% or ./@name = %locator%) or ./@id = //label[contains(normalize-space(string(.)), %locator%)]/@for) or ./@placeholder = %locator%)] | .//label[contains(normalize-space(string(.)), %locator%)]//.//*[self::input | self::textarea | self::select][not(./@type = 'submit' or ./@type = 'image' or ./@type = 'hidden')]";
							xpath = xpath_field.replace("%locator%", "'"+locator+"'");
						
							break;
							
		case("link"): String xpath_link =".//a[./@href][(((./@id = %locator% or contains(normalize-space(string(.)), %locator%)) or contains(./@title, %locator%) or contains(./@rel, %locator%)) or .//img[contains(./@alt, %locator%)])] | .//*[./@role = 'link'][((./@id = %locator% or contains(./@value, %locator%)) or contains(./@title, %locator%) or contains(normalize-space(string(.)), %locator%))]";
						    xpath = xpath_link.replace("%locator%", "'"+locator+"'");
						  
						    break;
		case("button"): String xpath_button= ".//input[./@type = 'submit' or ./@type = 'image' or ./@type = 'button'][(((./@id = %locator% or ./@name = %locator%) or contains(./@value, %locator%)) or contains(./@title, %locator%))] | .//input[./@type = 'image'][contains(./@alt, %locator%)] | .//button[((((./@id = %locator% or ./@name = %locator%) or contains(./@value, %locator%)) or contains(normalize-space(string(.)), %locator%)) or contains(./@title, %locator%))] | .//input[./@type = 'image'][contains(./@alt, %locator%)] | .//*[./@role = 'button'][(((./@id = %locator% or ./@name = %locator%) or contains(./@value, %locator%)) or contains(./@title, %locator%) or contains(normalize-space(string(.)), %locator%))]";
							xpath = xpath_button.replace("%locator%", "'"+locator+"'");
							
							break;
		case("link_or_button"): String xpath_link_or_button =".//a[./@href][(((./@id = %locator% or contains(normalize-space(string(.)), %locator%)) or contains(./@title, %locator%) or contains(./@rel, %locator%)) or .//img[contains(./@alt, %locator%)])] | .//input[./@type = 'submit' or ./@type = 'image' or ./@type = 'button'][((./@id = %locator% or contains(./@value, %locator%)) or contains(./@title, %locator%))] | .//input[./@type = 'image'][contains(./@alt, %locator%)] | .//button[(((./@id = %locator% or contains(./@value, %locator%)) or contains(normalize-space(string(.)), %locator%)) or contains(./@title, %locator%))] | .//input[./@type = 'image'][contains(./@alt, %locator%)] | .//*[(./@role = 'button' or ./@role = 'link')][((./@id = %locator% or contains(./@value, %locator%)) or contains(./@title, %locator%) or contains(normalize-space(string(.)), %locator%))]";
									xpath = xpath_link_or_button.replace("%locator%", "'"+locator+"'");
									
									break;
		case("content_contains"): String xpath_content_contains ="./descendant-or-self::*[contains(normalize-space(.), %locator%)]";
									xpath = xpath_content_contains.replace("%locator%", "'"+locator+"'");
									
									break;
		case("content_equals"): String xpath_content_equals ="./descendant-or-self::*[normalize-space(.)=%locator%]";
									xpath = xpath_content_equals.replace("%locator%", "'"+locator+"'");
									
									break;
		case("node_with_attribute"): String xpath_node_with_attribute =".//descendant-or-self::*[@*=%locator%]";
									xpath = xpath_node_with_attribute.replace("%locator%", "'"+locator+"'");
									
									break;
		case("node_with_content"): String xpath_node_with_content ="./descendant-or-self::text()[contains(normalize-space(.), %locator%)]/..";
									xpath = xpath_node_with_content.replace("%locator%", "'"+locator+"'");
									
									break;
		case("tagname_content"): String xpath_tagname_content = ".//%tagname%[contains(normalize-space(.), %locator%)]";
									String xpath_locator = xpath_tagname_content.replace("%locator%", "'"+locator+"'");
									xpath = xpath_locator.replace("%tagname%", tagname);
									
									break;
									
		case("locator_text"): String locator_text = ".//*[contains(normalize-space(text()),%locator%)]";
		                        xpath = locator_text.replace("%locator%", locator);
		                           break;
																
									
		case("select"): String xpath_select=".//select[(((./@id = %locator% or ./@name = %locator%) or ./@id = //label[contains(normalize-space(string(.)), %locator%)]/@for) or ./@placeholder = %locator%)] | .//label[contains(normalize-space(string(.)), %locator%)]//.//select";
									xpath = xpath_select.replace("%locator%", "'"+locator+"'");
									
									break;
		case("checkbox"): String xpath_checkbox = ".//input[./@type = 'checkbox'][(((./@id = %locator% or ./@name = %locator%) or ./@id = //label[contains(normalize-space(string(.)), %locator%)]/@for) or ./@placeholder = %locator%)] | .//label[contains(normalize-space(string(.)), %locator%)]//.//input[./@type = 'checkbox']";
									xpath = xpath_checkbox.replace("%locator%", "'"+locator+"'");
									
									break;
		case("radio"): String xpath_radio = ".//input[./@type = 'radio'][(((./@id = %locator% or ./@name = %locator%) or ./@id = //label[contains(normalize-space(string(.)), %locator%)]/@for) or ./@placeholder = %locator%)] | .//label[contains(normalize-space(string(.)), %locator%)]//.//input[./@type = 'radio']";
									xpath =xpath_radio.replace("%locator%", "'"+locator+"'");
									
									break;
		case("file"): String xpath_file = ".//input[./@type = 'file'][(((./@id = %locator% or ./@name = %locator%) or ./@id = //label[contains(normalize-space(string(.)), %locator%)]/@for) or ./@placeholder = %locator%)] | .//label[contains(normalize-space(string(.)), %locator%)]//.//input[./@type = 'file']";
									xpath = xpath_file.replace("%locator%", "'"+locator+"'");
								
									break;
		case("optgroup"): String xpath_optgroup = ".//optgroup[contains(./@label, %locator%)]";
									xpath = xpath_optgroup.replace("%locator%", "'"+locator+"'");
								
									break;
		case("option"): String xpath_option =".//option[(./@value = %locator% or contains(normalize-space(string(.)), %locator%))]";
									xpath = xpath_option.replace("%locator%", "'"+locator+"'");
									
									break;
		case("table"): String xpath_table =".//table[(./@id = %locator% or contains(.//caption, %locator%))]";
									xpath = xpath_table.replace("%locator%", "'"+locator+"'");
									
									break;
		case("tagname_name_id"): String xpath_tagname_name_id = ".//%tagname%[(./@id = %locator% or ./@name = %locator%)]";
									String xpath_tagname = xpath_tagname_name_id.replace("%tagname%", tagname);
									xpath = xpath_tagname.replace("%locator%", "'"+locator+"'");
									
									break;								
		case("component_name_id"): String xpath_component_name_id =".//*[(./@id = %locator% or ./@name = %locator%)]";
									xpath = xpath_component_name_id.replace("%locator%", "'"+locator+"'");
									
									break;
		default: System.out.println("try the other path like css");
							break;
		}
		*/
      return xpath;		
	}
}
