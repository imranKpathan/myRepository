package com.auto.bdd.cucumber;

import java.awt.AWTException;
import java.awt.RenderingHints.Key;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.auto.bdd.helpers.DataHelper;
import com.auto.bdd.xpath.webelement;
import com.auto.bdd.xpath.world;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDefinitions {
	
	public WebDriver driver;
	public stepDefinitions(){
    	driver = com.auto.bdd.cucumber.Hooks.driver;
    }
    @Given("^I goto the \"(.*?)\"$")
    public void i_open_the_url(String url) throws Throwable {
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    	driver.manage().window().maximize();
    }

    @When("^I fill in \"(.*?)\" with \"(.*?)\"$")
    public void i_input(String element, String value) throws InterruptedException {
    	
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("field", element, "");
    	WebElement elem = ele.element(name);
    	elem.sendKeys(value);
    	Thread.sleep(1000);
    }
//    public static final String name_random="00001";
    
    @When("^I fill in \"(.*?)\" with \"(.*?)\" along with random data$")
    public void i_input_random_data(String element, String value) throws InterruptedException {
    	//note a single Random object is reused here
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(123456);
        System.out.println("Generated : " + randomInt);         
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("field", element, "");
    	WebElement elem = ele.element(name);
    	String name_random = value+"_"+randomInt;
    	elem.sendKeys(name_random);
    	Thread.sleep(1000);
    }
    
    @When("^I click \"(.*?)\" in the \"(.*?)\" element$")   
    public void i_click(String element, String tagname) throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("tagname_content", element, tagname);
    	WebElement elem = ele.element(name);
    	elem.click();
    	Thread.sleep(10000);
    }
    
    @When("^I click component containing \"(.*?)\"$")
    public void i_click_containing_text(String text) throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("node_with_content", text, "");
    	WebElement elem = ele.element(name);
    	elem.click();
    	Thread.sleep(10000);
    }
    
    @Then("^the \"(.*?)\" field should have the value \"(.*?)\"$")
    public void field_should_have(String field, String value){
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("field", field, "");
    	WebElement elem = ele.element(name);
    	try{
    		if(elem.getText().equalsIgnoreCase(value)){
    			System.out.println("Element contains the specified value");
    		}
    	}catch(Exception e){
    		Assert.fail("element doesnt contains the specified value");
    	}
    }
    
    @Then("^the \"(.*?)\" field should not have the value \"(.*?)\"$")
    public void field_should_not_have(String field, String value){
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("field", field, "");
    	WebElement elem = ele.element(name);
    	try{
    		if(!elem.getText().equalsIgnoreCase(value)){
    			System.out.println("Element doesnt contains the specified value");
    		}
    	}catch(Exception e){
    		Assert.fail("Element contains the specified value");
    	}
    }
    
    @When("^I click \"(.*?)\" containing xpath \"(.*?)\"$")
    public void i_click_xpath(String element, String xpath) throws InterruptedException{
    	webelement ele = new webelement();
    	WebElement elem = ele.element(xpath);
    	elem.click();
    	Thread.sleep(10000);
    }
    
    
    @When("^I press \"(.*?)\"$")
    public void i_press(String buttontext)throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("button", buttontext, "");
    	WebElement elem = ele.element(name);
    	try{
    		elem.click();
    		Thread.sleep(1000);
    	}catch(Exception e){
    		
    	}
    }
    
    @When("^I clear the field \"(.*?)\"$")
    public void i_clear(String field)throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("field", field, "");
    	WebElement elem = ele.element(name);
    	try{
    		elem.clear();
    		Thread.sleep(1000);
    	}catch(Exception e){
    		System.out.println("Not able to find the element"+field);
    	}
    }
    
    @When("^I select \"(.*?)\" from \"(.*?)\"$")
    public void i_select(String option, String select)throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("select", select, "");
    	WebElement elem = ele.element(name);
    	try{
    		Select dropdown = new Select(elem);
    		dropdown.selectByVisibleText(option);
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Not able to locate the select option in the dropdown");
    	}
    }
    
    @When("^I check \"(.*?)\"$")
    public void i_check(String label)throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("field", label, "");
    	WebElement elem = ele.element(name);
    	try{
    		elem.click();
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Not able to check the label checkbox");
    	}
    }
    
    @When("^I attach the file \"(.*?)\" to \"(.*?)\"$")
    public void i_attach_file(String file, String element){
    	
    	world xpath = new world();
    	webelement ele = new webelement();
    	String filepath = System.getProperty("user.dir")+"/"+file;
    	String name = xpath.Xpath("file", element, "");
    	WebElement elem = ele.element(name);
    	try{
    		elem.sendKeys(filepath);
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Not able to attach a file");
    	}   	
    }
    
    @When("^I attach the file \"(.*?)\" to \"(.*?)\" given path \"(.*?)\"$")
    public void i_attach_file_given_path(String file, String element, String path){
    	
    	world xpath = new world();
    	webelement ele = new webelement();
    	String filepath = path+"/"+file;
    	String name = xpath.Xpath("file", element, "");
    	WebElement elem = ele.element(name);
    	try{
    		elem.sendKeys(filepath);
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Not able to attach a file");
    	}   	
    }
    
    @Then("^I should be on \"(.*?)\"$")
    public void i_should_be_on_url(String url){
    	try{
    		if(driver.getCurrentUrl().equalsIgnoreCase(url)){
    			System.out.println("Its in the given url");
    		}
    		
    	}catch(Exception e){
    		Assert.fail("Not in the given url");
    	}
    }
    
    @Then("^the response status code should be \"(.*?)\"$")
    public void response_status(String status){
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("content_contains", status, "");
    	WebElement elem = ele.element(name);
    	try{
    		if(elem.isDisplayed()){
    			System.out.println("Contains the response");
    		}
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Doesn't contains any response");
    	}   	
    }
    
    @Then("^I should see text matching \"(.*?)\"$")
    public void text_matching(String text){
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("content_contains", text, "");
    	WebElement elem = ele.element(name);
    	try{
    		if(elem.isDisplayed()){
    			System.out.println("Expected text should be present");
    		}
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Doesn't contains text");
    	}   
    }
    
    @Then("^the response should contain \"(.*?)\"$")
    public void the_response_should_contain(String text)  {
        // Write code here that turns the phrase above into concrete actions
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("content_contains", text, "");
    	WebElement elem = ele.element(name);
    	try{
    		if(elem.isDisplayed()){
    			System.out.println("Response contains "+text);
    		}
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Response doesn't contain "+text);
    	}
    }

    
    @Then("^ the response should contain \"(.*?)\"$")
    public void response_contain(String text){
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("content_contains", text, "");
    	WebElement elem = ele.element(name);
    	try{
    		if(elem.isDisplayed()){
    			System.out.println("Response contains "+text);
    		}
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail("Response doesn't contain "+text);
    	}
    }
    
    @Then("^I should see \"(.*?)\" in the \"(.*?)\" element$")
    public void i_should_see(String text, String element){
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("tagname_content", text, element);
    	WebElement elem = ele.element(name);
    	try{
    		if(elem.isDisplayed()){
    			System.out.println(text+" exists");
    		}
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail(text+" doesn't exists");
    	}
    }
    
    @Then("^the \"(.*?)\" button should be disabled$")
    public void button_disbled(String button){
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("button", button, "");
    	WebElement elem = ele.element(name);
    	try{
    		if(!elem.isEnabled()){
    			System.out.println(button + " is diabled");
    		}
    		Thread.sleep(1000);
    	}catch(Exception e){
    		Assert.fail(button + " is not diabled");
    	}
    }
    
    @When("^I follow \"(.*?)\"$")
    public void i_follow(String linktext)throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("link", linktext, "");
    	WebElement elem = ele.element(name);
    	try{
    		elem.click();
    		Thread.sleep(1000);
    	}catch(Exception e){
    		
    	}
    }
    
    
    @When("^I enter \"(.*?)\" with component containing id/name \"(.*?)\"$")
    public void i_enter(String value, String element) throws InterruptedException{
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("component_name_id", element, "");
    	WebElement elem = ele.element(name);
    	elem.sendKeys(value);
    	Thread.sleep(10000);
    }
    
    @When("^I enter \"(.*?)\" component containing id or name \"(.*?)\" and in different frame \"(.*?)\"$")
    public void i_enter_in_frame_name(String value, String element, String frameName) throws InterruptedException{
    	final List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
        for (WebElement iframe : iframes) {
            System.out.println(iframe.getAttribute("id"));
        }
    	driver.switchTo().frame(frameName);
    	Thread.sleep(1000);
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("component_name_id", element, "");
    	WebElement elem = ele.element(name);
    	elem.sendKeys(value);
    	Thread.sleep(2000);
    	driver.switchTo().defaultContent();
    	Thread.sleep(4000);
    }
    
    @When("^I enter \"(.*?)\" with component containing id/name \"(.*?)\" and in different frame$")
    public void i_enter_frame(String value, String element) throws InterruptedException{
    	final List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
        for (WebElement iframe : iframes) {
            System.out.println(iframe.getAttribute("id"));
        }
    	driver.switchTo().frame("iframeBody");
    	Thread.sleep(1000);
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("component_name_id", element, "");
    	WebElement elem = ele.element(name);
    	elem.sendKeys(value);
    	Thread.sleep(2000);
    	driver.switchTo().defaultContent();
    	Thread.sleep(4000);
    }
    
    @Then("^I should see \"(.*?)\"$")
    public void i_see(String text) throws InterruptedException{
    	Thread.sleep(1000);
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("locator_text", text, "");
    	WebElement elem = ele.element(name);
    	try{
    	if(elem.isDisplayed()){
    		System.out.println("It exists");
    	}
    	}catch(Exception e){
    		Assert.fail("It doesnt exists");
    	}
    }
    	
    @Then("^I should not see \"(.*?)\"$")
    public void i_should_not_see(String text) throws InterruptedException{
    
    	Thread.sleep(1000);
    	world xpath = new world();
    	webelement ele = new webelement();
    	String name = xpath.Xpath("locator_text", text, "");
    	WebElement elem = ele.element(name);
    	try{
    	if(!elem.isDisplayed()){
    		System.out.println("It doesnt exists");
    	}}
    	catch(Exception e){
    		Assert.fail("It doesnt exists");
    	}
    }
    
    

}
