package com.auto.bdd.helpers;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import jxl.Sheet;
import jxl.Workbook;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DataFromExcel {
	
	 public void test_Google() throws Exception{
		 
//	  String FilePath="D:\\TestIn Progress ECLIPSE\\TestData.xls";
		 System.out.println("+++++++++++++++++++++++++++++++++"+System.getProperty("user.dir"));
		 String FilePath= System.getProperty("user.dir")+"\\src\\test\\resources\\testData\\TestData.xls";
	        FileInputStream fs= new FileInputStream(FilePath);
	        Workbook wb= Workbook.getWorkbook(fs);
	       
	        Sheet sh= wb.getSheet("Sheet1");
	        int totalrows= sh.getRows();
	        
	        String mydata= sh.getCell(0,0).getContents();
	        System.out.println(mydata);
	        
	        List<String> list = new ArrayList();
	        for(int i=0; i<=totalrows; i++)
	        {
	        	list.add(sh.getCell(0,i).getContents());  
//	        	System.out.println("Get Contents --"+sh.getCell(0,i).getContents());
	        }
	        System.out.println("Total list elements : "+list);
	        
	 }


	}

