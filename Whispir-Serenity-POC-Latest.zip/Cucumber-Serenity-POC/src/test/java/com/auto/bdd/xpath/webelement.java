package com.auto.bdd.xpath;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class webelement {

	public static WebDriver driver;
	public webelement(){
		driver = com.auto.bdd.cucumber.Hooks.driver;
	}
	
	public WebElement element(String xpath){
		return (driver.findElement(By.xpath(xpath)));
	}
	
	public List<WebElement> elements(String xpath){
		return (driver.findElements(By.xpath(xpath)));
	}
}
