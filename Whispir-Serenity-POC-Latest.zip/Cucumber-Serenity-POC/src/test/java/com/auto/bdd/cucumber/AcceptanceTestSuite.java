package com.auto.bdd.cucumber;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.junit.runner.RunWith;

import com.auto.bdd.cucumber.AcceptanceTestSuite;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features="src/test/resources/features",
tags = {"@verifySample002,@verifySample001"})
public class AcceptanceTestSuite {
	
	
	
}
